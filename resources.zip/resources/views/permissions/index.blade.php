@extends('layouts.app')
@push('pg_btn')
@can('create-permissions')
    <a href="{{ route('permissions.create') }}" class="btn btn-sm btn-neutral">Create New Permission</a>
@endcan
@endpush
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-5">
                <div class="card-header bg-transparent"><h3 class="mb-0">All Permissions</h3></div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <div>
                            <table class="table table-hover align-items-center">
                                <thead class="thead-light">
                                <tr>
                                    <th scope="col">Name</th>
                                </tr>
                                </thead>
                                <tbody class="list">
                                @foreach($permissions as $permission)
                                    <tr>
                                        <th scope="row">
                                            {{$permission->name}}
                                        </th>
                                    </tr>
                                @endforeach
                                </tbody>
                                <tfoot >
                                <tr>
                                    <td colspan="6">
                                        {{$permissions->links()}}
                                    </td>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
