<div class="container-fluid main">
    <div class="row login_page w-100">
        <div class="col-xs-2 col-sm-2   col-md-3 col-lg-3"></div>
        <div class="col-xs-8 col-sm-8 col-md-6 col-lg-6 main-div">

            <!-- Register -->
            <div class="post-container mt-4 px-3 pt-4 pb-4">
                <div class="row add-head">
                    <div class="col-12 mx-4">
                        <p class="text-center"><?php echo e(__('translation.login')); ?> </p>
                    </div>
                </div>

                <form>

                    <div class="row">
                        <div class="col-md-12 mx-4  text-right">
                            <?php if(session()->has('message')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('message')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session()->has('error')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-row">

                        <div class="col-12 mt-4 form-col text-right">
                            <input type="text" class="form-control form-bor text-right" placeholder="<?php echo e(__('translation.email')); ?>"
                                wire:model="email" aria-label="Email">
                        </div>
                        <div class="col-12 text-right">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error text-right"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      

                        <div class="col-12 mt-4 form-col">
                            <input type="password" class="form-control form-bor text-right" placeholder="<?php echo e(__('translation.password')); ?>"
                                wire:model="password" aria-label="Password">
                        </div>
                        <div class="col-12 text-right">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error text-right"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        

                    </div>

                    <div class="col-12 text-center">
                        <div class="row d-flex pt-4 ">
                            <div class="col-6 text-right">
                                
                            </div>
                            <div class="col-6 text-left">
                                <button type="submit" class=" btn  login_btn"

                                    wire:click.prevent="login">    <span wire:target="login" wire:loading.class="spinner-border spinner-border-sm"></span>
                                    <?php echo e(__('translation.login')); ?></button>
                            </div>
                        </div>
                    </div>
            </div>
            </form>

            <div class="col-xs-2  col-sm-2 col-md-3 col-lg-3"></div>

        </div>


    </div>
<?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\resources\views/livewire/login.blade.php ENDPATH**/ ?>