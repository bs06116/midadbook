@extends('layouts.frontend')
@section('content')
@include('frontend.common.header')
@livewire('login')

@endsection



