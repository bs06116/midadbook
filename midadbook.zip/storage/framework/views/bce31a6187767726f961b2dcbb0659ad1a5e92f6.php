<div>
    <form>
        <div class="text-center rounded-pill mt-4 px-1 py-1">
            <i class="fa fa-search  rounded-pill search" aria-hidden="true"></i>
            <input wire:model.debounce.500ms="search" class="px-4 rounded-pill text-right search-input" type="search">
        </div>
    </form>

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('item', ['post' => $post])->html();
} elseif ($_instance->childHasBeenRendered($post->id)) {
    $componentId = $_instance->getRenderedChildComponentId($post->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($post->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($post->id);
} else {
    $response = \Livewire\Livewire::mount('item', ['post' => $post]);
    $html = $response->html();
    $_instance->logRenderedChild($post->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function () {
            Livewire.on('triggerCommentDelete', array => {
                var r = confirm("Are you sure you want to delete comment?");
                if (r == true) {
                    Livewire.emit('deletePostComment'+array.post_id, array.comment_id, array.post_id);
                } 
            });

            Livewire.on('triggerPostReport', (msg) => {
                confirm(msg);
            });
        })
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\resources\views/livewire/showposts.blade.php ENDPATH**/ ?>