<ul class="m-b-0 chat-user-messages js-chatbox-display">
    <?php if($perPage <= $totalMessages): ?>
        <div class="col-sm-12 previous text-center"> 
            <button type="submit"  wire:click="loadMore(<?php echo e($perPage+5); ?>)" wireTarget="loadMore" class="btn btn-link shadow-none">
                Show Previous Message!
            </button>
        </div>
    <?php endif; ?>
    <?php
        $old_date = Carbon::now();
    ?>
    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="clearfix">
            <?php if(Carbon::parse($old_date)->format('d-m-Y') != Carbon::parse($item->created_at)->format('d-m-Y')): ?>
                <p class="text-center text-secondary">
                    <small>
                        <?php if(Carbon::parse($item->created_at)->format('d-m-Y') == Carbon::now()->format('d-m-Y')): ?>
                            Today
                        <?php else: ?>
                            <?php echo e(Carbon::parse($item->created_at)->format('d-m-Y')); ?>

                        <?php endif; ?>
                    </small>
                </p>
            <?php endif; ?>
            <div class="message-data <?php echo e(auth()->user()->id == $item->sender_id ? 'text-right ' : ''); ?>">
                <small class="text-secondary message-data-time"><?php echo e(Carbon::parse($item->created_at)->format('h:i a')); ?> </small>
            </div>
            <div class=" <?php echo e(auth()->user()->id == $item->sender_id ? 'text-right float-right' : ''); ?>">
                <div class="message <?php echo e(auth()->user()->id == $item->sender_id ? 'other-message' : 'my-message'); ?> "> 
                    <?php echo e($item->message); ?>

                </div>
                <?php if(auth()->user()->id == $item->sender_id && $item->read_at != null && $loop->last): ?>
                    <br>
                    <small class="msg-time text-secondary" title="<?php echo e($item->read_at); ?>">
                        Seen
                    </small>
                <?php endif; ?>
            </div>
        </li>
        <?php
            $old_date = $item->created_at;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\resources\views/livewire/chat/chat-messages.blade.php ENDPATH**/ ?>