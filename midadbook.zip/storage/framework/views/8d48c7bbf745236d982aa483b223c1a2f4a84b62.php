<div>
    <?php if(!$already_rated): ?>
        <?php if(Auth::user()->id != $user_id): ?>
            <div class="mt-3">
                
                <form wire:submit.prevent="store">
                    <div class="form-group">
                        <label for="comment">Your rating</label>
                        <div class="rating-wrap">
                            <ul class="rating-stars">
                                <li style="width:<?php echo e($rating*20); ?>%" class="stars-active">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <a href="#" wire:click.prevent="setRating('<?php echo e($i); ?>')">
                                            <i class="fa fa-star"></i> 
                                        </a>
                                    <?php endfor; ?>
                                </li>
                                <li>
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <a href="#" wire:click.prevent="setRating('<?php echo e($i); ?>')">
                                            <i class="fa fa-star"></i> 
                                        </a>
                                    <?php endfor; ?>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="comment">Comment</label>
                        <textarea wire:model="comment" class="form-control shadow-none rounded-0 text-right" id="comment" cols="30" rows="3"></textarea>
                        <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small id="helpId" class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group text-center">
                        <button class="btn btn-primary" wireTarget="store" type="submit">
                            Save
                        </button>
                    </div>
                </form>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <h3>Rate the User</h3>
        <div class="form-group">
            <label for="comment">Your rating</label>
            <div class="rating-wrap">
                <ul class="rating-stars">
                    <li style="width:<?php echo e($rating*20); ?>%" class="stars-active">
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <i class="fa fa-star"></i> 
                        <?php endfor; ?>
                    </li>
                    <li>
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <i class="fa fa-star"></i> 
                        <?php endfor; ?>
                    </li>
                </ul>
            </div>
        </div>
        <div class="form-group">
            <label for="comment">Comment</label>
            <textarea class="form-control shadow-none rounded-0 text-right" id="comment" cols="30" rows="3" disabled><?php echo e($comment); ?></textarea>
            <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small id="helpId" class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    <?php endif; ?>
</div><?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\resources\views/livewire/user-rating-form.blade.php ENDPATH**/ ?>