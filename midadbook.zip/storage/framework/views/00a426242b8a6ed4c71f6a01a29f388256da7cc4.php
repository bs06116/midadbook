<div class="card chat-app shadow">
    <div id="plist" class="people-list" style="<?php echo e(!empty($receiver) ? '' : 'left:0px;'); ?>">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('chat.chat-user-list', ['user_id' => request()->user_id])->html();
} elseif ($_instance->childHasBeenRendered('ErETf5D')) {
    $componentId = $_instance->getRenderedChildComponentId('ErETf5D');
    $componentTag = $_instance->getRenderedChildComponentTagName('ErETf5D');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ErETf5D');
} else {
    $response = \Livewire\Livewire::mount('chat.chat-user-list', ['user_id' => request()->user_id]);
    $html = $response->html();
    $_instance->logRenderedChild('ErETf5D', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <div class="chat <?php echo e(empty($receiver) ? 'd-none' : ''); ?> ">
        <?php if(!empty($receiver)): ?>
            <div class="chat-header clearfix">
                <div class="row d-flex justify-content-start align-items-center ">
                    <div class="col-lg-10 col-9 text-truncate d-flex justify-content-start align-items-center text-dark">
                        <button class="btn btn-link shadow-none back-to-chat-list" wire:click="resetChat">
                            <i class="fa fa-arrow-left" aria-hidden="true"></i>
                        </button>
                        <img src="<?php echo e($receiver->getUserImageUrl()); ?>" class="rounded-circle" alt="<?php echo e($receiver->name); ?>">
                        
                        <div class="chat-about">
                            <h6 class="mb-0 "><?php echo e($receiver->name); ?></h6>
                            <small class="d-none is-typing"><i>Typing...</i></small>
                            <small class="text-secondary online-status">
                                <?php if(Cache::has('is_online' . $receiver->id)): ?>
                                    <i class="fa fa-circle online"></i> online
                                <?php elseif(!empty($receiver->last_seen)): ?>
                                    <i class="" style="width: 50px">Last seen: <?php echo e(Carbon::parse($receiver->last_seen)->diffForHumans()); ?></i>
                                <?php endif; ?>
                            </small>
                        </div>
                    </div>
                    <div class="col-lg-2 col-3 hidden-sm text-right">
                        <?php if($isDelete): ?>
                            <div class="btn-group btn-group-sm" role="group" aria-label="Basic example"> 
                                <button type="button" class="btn btn-danger btn-sm shadow-none" wireTarget="deleteChat('<?php echo e(($receiver->id)); ?>')" wire:click="deleteChat('<?php echo e(($receiver->id)); ?>')"><i class="fa fa-check"></i></button>
                                <button type="button" class="btn btn-light btn-sm shadow-none" wire:loading.attr="disabled" wire:click="$set('isDelete', false)"><i class="fa fa-times"></i></button>
                            </div>
                        <?php else: ?> 
                            <button class="btn btn-link shadow-none text-danger" wire:loading.attr="disabled" wire:click="$set('isDelete', true)"><i class="fa fa-trash" aria-hidden="true"></i></button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="chat-history chat-scrollable" wire:loading.delay.class="opacity-2" style="overflow-y: auto;">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('chat.chat-messages', ['user_id' => $receiver->id])->html();
} elseif ($_instance->childHasBeenRendered('gVmIRp4')) {
    $componentId = $_instance->getRenderedChildComponentId('gVmIRp4');
    $componentTag = $_instance->getRenderedChildComponentTagName('gVmIRp4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gVmIRp4');
} else {
    $response = \Livewire\Livewire::mount('chat.chat-messages', ['user_id' => $receiver->id]);
    $html = $response->html();
    $_instance->logRenderedChild('gVmIRp4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
            <div class="chat-message clearfix bg-light">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('chat.chat-form', ['user_id' => $receiver->id])->html();
} elseif ($_instance->childHasBeenRendered('zUEDrnI')) {
    $componentId = $_instance->getRenderedChildComponentId('zUEDrnI');
    $componentTag = $_instance->getRenderedChildComponentTagName('zUEDrnI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zUEDrnI');
} else {
    $response = \Livewire\Livewire::mount('chat.chat-form', ['user_id' => $receiver->id]);
    $html = $response->html();
    $_instance->logRenderedChild('zUEDrnI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        <?php endif; ?> 
    </div>
</div><?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\resources\views/livewire/chat/chat-container.blade.php ENDPATH**/ ?>