<div>
    <div class="text-center">
        <?php if( $comments->hasPages() ): ?>
            <button wire:click="loadMoreItems" class="bg-transparent border-0 load-previous-comments-btn" type="button">
                <small>Load Previous Comments</small>   
            </button>
        <?php endif; ?>
    </div>
    <?php $__currentLoopData = $comments->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row single_comment mb-3 bg-light m-2 rounded border">
            <div class="col-2 comment_btn icons_container h-100 d-flex align-items-center justify-content-center ">
                <?php if(Auth::check()): ?>
                    <?php if($comment->user_id == Auth::user()->id): ?>
                        <?php if($edit_comment_id == $comment->id): ?>
                            <div class="py-2">
                                <a class="mr-2" style="cursor: pointer;" wire:click.prevent="updateComment(<?php echo e($comment->id); ?>)"><i class="far fa-check" style="color: #5d001d; font-size: 18px !important;" ></i></a>
                                <a class="text-danger" style="cursor: pointer;" wire:click.prevent="cancelCommentEdit"><i class="fa fa-times" style="font-size: 18px !important;" aria-hidden="true"></i></a>
                            </div>
                        <?php else: ?>
                            <a class="mr-2" style="cursor: pointer;" wire:click.prevent="editComment(<?php echo e($comment->id); ?>)"><i class="fa fa-edit" aria-hidden="true"  style="color: #5d001d; font-size: 18px !important;"></i></a>
                            <a class="text-danger" style="cursor: pointer;" wire:click.prevent="$emit('triggerCommentDelete',{'comment_id' : <?php echo e($comment->id); ?>, 'post_id' : <?php echo e($comment->post_id); ?>})"><i class="fa fa-trash"  style="font-size: 18px !important;" aria-hidden="true"></i></a>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>            
            <div class="col-10 comment_box pb-2">
                <a href="<?php echo e(route('user_profile',$comment->user->name)); ?>"> <?php echo e($comment->user->name); ?></a><br>
                <?php if($edit_comment_id == $comment->id): ?>
                    <input type="text" class="form-control" wire:model="edit_comment_value">
                    <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php else: ?>
                    <?php echo e($comment->comment); ?><br>
                <?php endif; ?>
                <small class="text-muted"><?php echo e(Carbon\Carbon::parse($comment->updated_at)->diffForHumans()); ?></small>
            </div>
            <div class="col-2 pl-1 img d-flex align-items-center justify-content-center">
                <img src="<?php echo e(url('storage/' . $comment->user->profile_photo)); ?>"
                alt="<?php echo e($comment->user->name); ?>">
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div><?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\resources\views/livewire/comment-list.blade.php ENDPATH**/ ?>