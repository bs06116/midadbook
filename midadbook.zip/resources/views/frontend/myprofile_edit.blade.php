@extends('layouts.frontend')
@section('content')
@include('frontend.common.header_register')

@livewire('myprofile-edit')

@endsection



