@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-md-12">
            <iframe src="/filemanager" style="width: 100%; height: 500px; overflow: hidden; border: none;"></iframe>
        </div>
    </div>
@endsection
