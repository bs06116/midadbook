
<?php $__env->startSection('content'); ?>
    <?php if(Auth::check()): ?>
        <?php echo $__env->make('frontend.common.header_register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php else: ?>
        <?php echo $__env->make('frontend.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php endif; ?>

    <div class="container-fluid main">
        <div class="row w-100">
            <div class="col-xs-1 col-sm-2  px-4 col-md-3 col-lg-3">

            </div>
            <div class="col-xs-10 col-sm-8 col-md-6 col-lg-6 main-div">
                <!-- search input -->

                <!-- Post -->
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('showposts')->html();
} elseif ($_instance->childHasBeenRendered('TAaFCnH')) {
    $componentId = $_instance->getRenderedChildComponentId('TAaFCnH');
    $componentTag = $_instance->getRenderedChildComponentTagName('TAaFCnH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TAaFCnH');
} else {
    $response = \Livewire\Livewire::mount('showposts');
    $html = $response->html();
    $_instance->logRenderedChild('TAaFCnH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\resources\views/frontend/welcome.blade.php ENDPATH**/ ?>