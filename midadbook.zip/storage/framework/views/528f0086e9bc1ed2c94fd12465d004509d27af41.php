
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.common.header_register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('myprofile-edit')->html();
} elseif ($_instance->childHasBeenRendered('yyCLsyM')) {
    $componentId = $_instance->getRenderedChildComponentId('yyCLsyM');
    $componentTag = $_instance->getRenderedChildComponentTagName('yyCLsyM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yyCLsyM');
} else {
    $response = \Livewire\Livewire::mount('myprofile-edit');
    $html = $response->html();
    $_instance->logRenderedChild('yyCLsyM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\resources\views/frontend/myprofile_edit.blade.php ENDPATH**/ ?>