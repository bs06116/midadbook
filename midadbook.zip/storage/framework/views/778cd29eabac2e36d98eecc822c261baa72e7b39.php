<div class="post-container mt-4 px-3 pt-4">

    <?php if($post->book_type === 1): ?>
        <div class="butn d-inline">
            <button class='rounded-pill'><span class='px-1'><?php echo e(__('translation.required')); ?></span>
        </div>
    <?php elseif($post->book_type === 2): ?>
        <div class="butnborrow d-inline">
            <button class='rounded-pill'><span class='px-1'><?php echo e(__('translation.borrow_book')); ?></span>
        </div>
    <?php elseif($post->book_type === 3): ?>
        <div class="butnsell d-inline">
            <button class='rounded-pill'><span class='px-1'><?php echo e(__('translation.sell')); ?></span>
        </div>
    <?php else: ?>
        <div class="butnexchange d-inline">
            <button class='rounded-pill'><span class='px-1'><?php echo e(__('translation.exchange')); ?></span>
        </div>

    <?php endif; ?>

    <div class="text-right d-inline user-info">
        <span class="text-muted"><span>@</span><?php echo e($post->user->username); ?></span>
        <h6 class="d-inline"><a href="<?php echo e($post->user->username); ?>"><?php echo e($post->user->name); ?></a></h6>
        <span class="d-block text-right text-muted"><?php echo e($post->user->city->name); ?></span>
    </div>
    <img src="<?php echo e(url('storage/' . $post->user->profile_photo)); ?>" class="user-img " alt="<?php echo e($post->user->name); ?>">
    <hr class="mt-3">
    <div class="post-title text-right pt-2">
        <h4><?php echo e($post->post_title); ?> </h4>
        <p class="text-muted pt-2"><?php echo e($post->post_body); ?>

        </p>
    </div>
    <?php if(!empty($post->featured_image) && !empty($post->image_second)): ?>
        <div class="d-flex post_images ">
            <img class="w-50 mr-1" src="<?php echo e(url('storage/' . $post->featured_image)); ?>"
                alt="<?php echo e($post->post_title); ?>">
            <img class="w-50" src="<?php echo e(url('storage/' . $post->image_second)); ?>" alt="<?php echo e($post->post_title); ?>">
        </div>
    <?php else: ?>
        <div class="post-img">
            <img src="<?php echo e(url('storage/' . $post->featured_image)); ?>" alt="<?php echo e($post->post_title); ?>">
        </div>
    <?php endif; ?>


    <div class="row f-post pt-2">
        <div class="col-5 col-xs-5 col-sm-5 col-md-6 col-lg-6 col-xl-6">
            <p class="whatsapp mr-2">
                <?php if($post->user->show_phone_number): ?>
                    <a href=" https://wa.me/<?php echo e($post->user->phone_number); ?>"><?php echo e($post->user->phone_number); ?></a> 
                    <img src="<?php echo e(asset('assets/img/front/whatsapp_ic.png')); ?>" alt="">
                <?php else: ?>
                    <?php echo e($post->user->show_phone_number ? $post->user->phone_number : str_repeat("*", strlen($post->user->phone_number))); ?>

                    <img src="<?php echo e(asset('assets/img/front/whatsapp_ic.png')); ?>" alt="">
                <?php endif; ?>
            </p>
        </div>
        <div class="col-7 col-xs-7 col-sm-7 col-md-6 col-lg-6 col-xl-6">

            <div class="row d-flex">
                <div class="col-6 text-right">
                    <p class="message"><?php echo e($comment_count); ?> <img src="<?php echo e(asset('assets/img/front/comment_ic.png')); ?>" alt="">
                    </p>
                </div>

                <div class="col-6 text-center">
                    <p class="heart">
                        
                        <?php echo e($post->like->count()); ?>

                        <?php if(!Auth::check()): ?>
                            <img wire:key="like-<?php echo e($post->id); ?>" 
                                wire:loading.attr="disabled" src="<?php echo e(asset('assets/img/front/heart_line.png')); ?>"
                                alt="">
                        <?php else: ?>
                        <?php if(isset($postId)): ?>
                        <img wire:key="dislike-<?php echo e($post->id); ?>" wire:click="dislike(<?php echo e($post->id); ?>)"
                                    wire:loading.attr="disabled"
                                    src="<?php echo e(asset('assets/img/front/heart_filled.png')); ?>" alt="">
                            <?php else: ?>
                                <img wire:key="like-<?php echo e($post->id); ?>" wire:click="like(<?php echo e($post->id); ?>)"
                                    wire:loading.attr="disabled" src="<?php echo e(asset('assets/img/front/heart_line.png')); ?>"
                                    alt="">
                            <?php endif; ?>

                            <a href="#" class="pl-5 ml-3 text-danger" wire:click.prevent="report(<?php echo e($post->id); ?>)"><i class="fas fa-exclamation-triangle"></i></a>
                        <?php endif; ?>

                    </p>

                </div>
            </div>
        </div>

    </div>
    <div class="pb-3 comment_div">
        <?php if(Auth::check()): ?>
            <div class="row single_comment mb-3 py-2 m-2">
                <div class="col-2 icons_container comment_btn h-100 ">
                    <button class="btn mt-1 " wire:click.prevent="commentStore(<?php echo e($post->id); ?>)"><i class="far fa-paper-plane"></i></button>
                </div>
                <div class="col-10 comment_box">
                    <input type="text" class="form-control" wire:model="comment">
                    <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-2 pl-1 img d-flex justify-content-center align-items-center">
                    <img src="<?php echo e(url('storage/' . Auth::user()->profile_photo)); ?>"
                    alt="<?php echo e(Auth::user()->name); ?>">
                </div>
            </div>
        <?php endif; ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('comment-list', ['post_id' => $post->id])->html();
} elseif ($_instance->childHasBeenRendered('OmOxvXN')) {
    $componentId = $_instance->getRenderedChildComponentId('OmOxvXN');
    $componentTag = $_instance->getRenderedChildComponentTagName('OmOxvXN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OmOxvXN');
} else {
    $response = \Livewire\Livewire::mount('comment-list', ['post_id' => $post->id]);
    $html = $response->html();
    $_instance->logRenderedChild('OmOxvXN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>



<?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\resources\views/livewire/item.blade.php ENDPATH**/ ?>