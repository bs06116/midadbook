
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('login')->html();
} elseif ($_instance->childHasBeenRendered('wEZpN0b')) {
    $componentId = $_instance->getRenderedChildComponentId('wEZpN0b');
    $componentTag = $_instance->getRenderedChildComponentTagName('wEZpN0b');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wEZpN0b');
} else {
    $response = \Livewire\Livewire::mount('login');
    $html = $response->html();
    $_instance->logRenderedChild('wEZpN0b', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\resources\views/frontend/login.blade.php ENDPATH**/ ?>