
<?php $__env->startSection('content'); ?>
<?php if(Auth::check()): ?>
<?php echo $__env->make('frontend.common.header_register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<?php echo $__env->make('frontend.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<div class="container-fluid main">
    <div class="row w-100">
        <div class="col-xs-1 col-sm-2   col-md-3 col-lg-3"></div>
        <div class="col-xs-10 col-sm-8 col-md-6 col-lg-6 main-div">
            <!-- search input -->
            <!-- <form>
                <div class="text-center rounded-pill px-1 py-1">
                    <i class="fa fa-search  rounded-pill " aria-hidden="true"></i>
                    <input class="px-2 rounded-pill text-right" type="text">
                </div>
            </form> -->

            <div class="profile w-100 text-center">
                <div class="profile-info">
                <img class="profile-img  " src="<?php echo e(url('storage/' . $user->profile_photo)); ?>" alt="">
                <div class="">
                <p class="d-inline pr-3"><span>@</span><?php echo e($user->username); ?></p>
                <h6 class="d-inline-block ml-3 pl-3"><?php echo e($user->name); ?></h6>
                <br>
                <p class="whatsapp d-inline text-secondary pr-3"><?php echo e($user->show_phone_number ? $user->phone_number : str_repeat("*", strlen($user->phone_number))); ?>

                  <img  class=" ml-" src="<?php echo e(asset('assets/img/front/whatsapp_ic.png ')); ?>" alt=""></p>
                <p class="d-inline text-secondary pl-3"><?php echo e($user->city->name); ?>

                   <i class="fal fa-map-marker-alt"></i></p>

                    <div class="rating-wrap">
                        <ul class="rating-stars">
                            <li style="width:<?php echo e(($user->ratings->sum('rating')/($user->ratings->count() == 0 ? 1 : $user->ratings->count()))*20); ?>%" class="stars-active">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fa fa-star"></i> 
                                <?php endfor; ?>
                            </li>
                            <li>
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fa fa-star"></i> 
                                <?php endfor; ?>
                            </li>
                        </ul>
                    </div>

                   <br>
                   <div class="social-links ">
                   <a class=" good-reads" href=""><img src="<?php echo e(asset('assets/img/front/good_reads_logo.png ')); ?>" alt=""></a>
                   <a class=" twitter " href=""><i class="fab fa-twitter"></i></a>
                   <button class="btn counting">30 <span>counting</span></button>
                   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('chat.profile-chat-button', ['user_id' => $user->id])->html();
} elseif ($_instance->childHasBeenRendered('StZ5czF')) {
    $componentId = $_instance->getRenderedChildComponentId('StZ5czF');
    $componentTag = $_instance->getRenderedChildComponentTagName('StZ5czF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('StZ5czF');
} else {
    $response = \Livewire\Livewire::mount('chat.profile-chat-button', ['user_id' => $user->id]);
    $html = $response->html();
    $_instance->logRenderedChild('StZ5czF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                  </div>
              </div>
                </div>
                <?php if(auth()->guard()->check()): ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-rating-form',['user_id' => $user->id])->html();
} elseif ($_instance->childHasBeenRendered('HXiCYbd')) {
    $componentId = $_instance->getRenderedChildComponentId('HXiCYbd');
    $componentTag = $_instance->getRenderedChildComponentTagName('HXiCYbd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HXiCYbd');
} else {
    $response = \Livewire\Livewire::mount('user-rating-form',['user_id' => $user->id]);
    $html = $response->html();
    $_instance->logRenderedChild('HXiCYbd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php endif; ?>
              </div>

            <!-- Post -->

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="post-container mt-4 px-3 pt-4">

                <?php if($post->book_type === 1): ?>
                    
                 <?php elseif($post->book_type === 2): ?>
                    <div class="butnborrow d-inline">
                        <button class='rounded-pill'><span class='px-1'><?php echo e(__('translation.borrow_book')); ?></span>
                    </div>
                <?php elseif($post->book_type === 3): ?>
                    <div class="butnsell d-inline">
                        <button class='rounded-pill'><span class='px-1'><?php echo e(__('translation.sell')); ?></span>
                    </div>
                <?php else: ?>
                    <div class="butnexchange d-inline">
                        <button class='rounded-pill'><span class='px-1'><?php echo e(__('translation.exchange')); ?></span>
                    </div>

                <?php endif; ?>



                
                <div class="post-title text-right pt-2">
                    <h4><?php echo e($post->post_title); ?> </h4>
                    <p class="text-muted pt-2"><?php echo e($post->post_body); ?>

                    </p>
                </div>

                <div class="post-img">
                    <img src="<?php echo e(url('storage/' . $post->featured_image)); ?>" alt="<?php echo e($post->post_title); ?>">
                </div>
                <div class="row f-post pt-2">
                    <div class="col-5 col-xs-5 col-sm-5 col-md-6 col-lg-6 col-xl-6">
                        <!-- <p class="whatsapp mr-2"><?php echo e($post->user->phone_number); ?> <img
                                src="<?php echo e(asset('assets/img/front/whatsapp_ic.png')); ?>" alt="">
                        </p> -->
                        <div class="butn d-inline">
                        <button class='rounded-pill'><span class='px-1'><?php echo e(__('translation.required')); ?></span>
                        </div>
                    </div>
                    <div class="col-7 col-xs-7 col-sm-7 col-md-6 col-lg-6 col-xl-6">
                        <div class="row d-flex">
                            <div class="col-6 text-right">
                                <p class="message">100 <img src="<?php echo e(asset('assets/img/front/comment_ic.png')); ?>" alt="">
                                </p>
                            </div>
                            <div class="col-6 text-center">
                                <p class=" heart ">100 <img src="<?php echo e(asset('assets/img/front/heart_line.png')); ?>" alt="">
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
                <hr>
        
        <div class="row pb-3 d-flex comment_div">
            <div class="col-2 pl-1 img">
                <img src="<?php echo e(url('storage/' . $post->user->profile_photo)); ?>" 
                alt="<?php echo e($post->user->name); ?>">
            </div>
                <div class="col-8 comment_box">
                
                <input type="text" class="form-control" id="validationCustom01"  >
                </div>
                <div class="col-2 comment_btn">
                    <button class="btn mt-1 " type="submit"><i class="far fa-paper-plane"></i></button>
                </div>
        </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-xs-1  col-sm-2 col-md-3 col-lg-3"></div>
    </div>

</div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\resources\views/frontend/profile.blade.php ENDPATH**/ ?>