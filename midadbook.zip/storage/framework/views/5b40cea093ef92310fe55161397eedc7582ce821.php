<div>
    <div class="input-group mb-3">
        <div class="input-group-prepend">
            <span class="input-group-text bg-white"><i class="fa fa-search"></i></span>
        </div>
        <input type="text" class="form-control shadow-none" placeholder="Search..." wire:model.debounce.500ms="search">
    </div>
    <ul class="list-unstyled chat-list mt-2 mb-0" style="overflow-y: auto;" wire:loading.delay.class="opacity-2" wire:target="search">
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="clearfix <?php echo e(isset($receiver->id) ? ($receiver->id == $item->id ? 'chat-active' : '') : ''); ?>">
                <a href="#" class="btn shadow-none p-0 d-flex justify-content-start align-items-center text-dark text-left" wire:click.prevent="$emit('fromUserList', '<?php echo e(($item->id)); ?>', true)">
                    
                    <image src="<?php echo e($item->getUserImageUrl()); ?>" name="<?php echo e($item->name); ?>" width="50" height="50"/>
                    <div class="about">
                        <div class="name"><?php echo e($item->name); ?></div>
                        <small class="status"> 
                            <?php if(Cache::has('is_online' . $item->id)): ?>
                                <i class="fa fa-circle online"></i> online
                            <?php else: ?>
                                <i class="fa fa-circle online text-secondary"></i> <?php echo e(Carbon::parse($item->last_seen)->diffForHumans()); ?>

                            <?php endif; ?>
                        </small>
                    </div>
                    <span class="badge badge-danger ml-3 badge-pill read-<?php echo e($item->id); ?>"><?php echo e($item->unread > 0 ? $item->unread : ''); ?></span>
                </a>
            </li>
            <div class="is-flex justify-content-center text-center">
                <span class="m-0"></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
            <p class="p-4 text-center text-secondary">
                No Chat User Found
            </p>
        <?php endif; ?>
    </ul>
</div><?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\resources\views/livewire/chat/chat-user-list.blade.php ENDPATH**/ ?>