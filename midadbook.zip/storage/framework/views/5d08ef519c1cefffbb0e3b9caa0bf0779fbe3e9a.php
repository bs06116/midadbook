<a onclick="openChatBubble()" href="#">
    
    <img src="<?php echo e(asset('assets/img/front/send_ic.png')); ?>">
     <?php echo auth()->user()->receive_messages()->where('read_at', null)->count() > 0 ? '<i class="badge1">'.auth()->user()->receive_messages()->where('read_at', null)->count().'</i>' : ''; ?>

</a><?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\resources\views/livewire/chat/chat-header-notification.blade.php ENDPATH**/ ?>