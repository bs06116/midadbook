<?php echo e($slot); ?>

<?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>