<div>
    <button type="button" class="btn btn-primary" wire:click.prevent="$emit('fromUserList', '<?php echo e(($user_id)); ?>', true)"><i class="fa-envelope-open fa"></i> Message</button>
</div>
<?php /**PATH C:\Users\Abhishek Burkule\Downloads\midadbook-main\midadbook\resources\views/livewire/chat/profile-chat-button.blade.php ENDPATH**/ ?>